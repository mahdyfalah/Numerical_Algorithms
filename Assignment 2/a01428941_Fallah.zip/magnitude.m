function m = magnitude(x,y)
  m = max(x,y)/min(x,y);
endfunction
