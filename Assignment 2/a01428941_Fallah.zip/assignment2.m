% please uncomment parts base on what part of assignments needs to get run

% partI();
partII();
