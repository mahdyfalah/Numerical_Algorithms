% please uncomment each functions that should be tested

partI();
% partII();
% partIII();

