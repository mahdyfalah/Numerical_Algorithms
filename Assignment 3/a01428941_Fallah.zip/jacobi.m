function M = jacobi(M)
  M = diag(diag(M));
endfunction
